{{- define "llmboost.validateReleaseName" -}}
{{- if .Values.singleton.enforceReleaseName -}}
{{- $expected := "llmboost" -}}
{{- if ne .Release.Name $expected -}}
{{- fail (printf "This chart is a namespace-singleton and must be installed with release name '%s'. Example: helm upgrade --install %s <chart> -n %s" $expected $expected .Release.Namespace) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "llmboost.baseName" -}}
{{- if .Values.singleton.enforceReleaseName -}}
llmboost
{{- else -}}
{{- .Release.Name -}}
{{- end -}}
{{- end -}}

{{/*
Expand the name of the chart.
*/}}
{{- define "llmboost.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "llmboost.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "llmboost.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "llmboost.labels" -}}
helm.sh/chart: {{ include "llmboost.chart" . }}
{{ include "llmboost.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "llmboost.selectorLabels" -}}
app.kubernetes.io/name: {{ include "llmboost.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "llmboost.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "llmboost.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
